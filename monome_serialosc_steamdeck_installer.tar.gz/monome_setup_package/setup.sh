#!/bin/bash
# Exit immediately if a command exits with a non-zero status.
set -e

echo "============================================"
echo "Monome SerialOSC Setup for Steam Deck"
echo "============================================"
echo "This script will install serialoscd, libmonome,"
echo "the udev rule, and the systemd service."
echo "It requires sudo access and will temporarily"
echo "disable the read-only filesystem."
echo "--------------------------------------------"

# Get sudo password upfront and keep the session alive
echo "Please enter your sudo password if prompted:"
sudo -v
while true; do sudo -n true; sleep 60; kill -0 "$$" || exit; done 2>/dev/null &
SUDO_KEEPALIVE_PID=$!
# Ensure the keepalive stops when the script exits
trap "kill $SUDO_KEEPALIVE_PID" EXIT

# Define source paths (relative to script location) and target paths
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
SERIALOSCD_SOURCE="$SCRIPT_DIR/usr/local/bin/serialoscd"
LIBMONOME_SOURCE_DIR="$SCRIPT_DIR/usr/local/lib"
UDEV_RULE_SOURCE="$SCRIPT_DIR/etc/udev/rules.d/99-monome.rules"
SYSTEMD_SERVICE_SOURCE="$SCRIPT_DIR/etc/systemd/system/serialoscd@.service"

SERIALOSCD_TARGET="/usr/local/bin/serialoscd"
LIBMONOME_TARGET_DIR="/usr/local/lib"
UDEV_RULE_TARGET="/etc/udev/rules.d/99-monome.rules"
SYSTEMD_SERVICE_TARGET="/etc/systemd/system/serialoscd@.service"

# --- Installation Steps ---

echo "[Step 1/8] Disabling read-only filesystem..."
sudo steamos-readonly disable

echo "[Step 2/8] Installing required system dependencies (libuv, liblo)..."
# --noconfirm avoids asking user, --needed skips if already installed
sudo pacman -Syu --noconfirm --needed libuv liblo || echo "WARNING: Failed to automatically install dependencies. Please install libuv and liblo manually using pacman."

echo "[Step 3/8] Creating target directories (if needed)..."
sudo mkdir -p "$(dirname "$SERIALOSCD_TARGET")"
sudo mkdir -p "$LIBMONOME_TARGET_DIR"
sudo mkdir -p "$(dirname "$UDEV_RULE_TARGET")"
sudo mkdir -p "$(dirname "$SYSTEMD_SERVICE_TARGET")"

echo "[Step 4/8] Copying files..."
sudo cp "$SERIALOSCD_SOURCE" "$SERIALOSCD_TARGET"
sudo cp "$LIBMONOME_SOURCE_DIR"/libmonome.so* "$LIBMONOME_TARGET_DIR/"
sudo cp "$UDEV_RULE_SOURCE" "$UDEV_RULE_TARGET"
sudo cp "$SYSTEMD_SERVICE_SOURCE" "$SYSTEMD_SERVICE_TARGET"
echo "Files copied."

echo "[Step 5/8] Setting permissions..."
sudo chmod 755 "$SERIALOSCD_TARGET"
sudo chmod 644 "$LIBMONOME_TARGET_DIR"/libmonome.so*
sudo chmod 644 "$UDEV_RULE_TARGET"
sudo chmod 644 "$SYSTEMD_SERVICE_TARGET"
echo "Permissions set."

echo "[Step 6/8] Reloading system daemons..."
sudo systemctl daemon-reload
sudo udevadm control --reload-rules
echo "Daemons reloaded."

echo "[Step 7/8] Adding user 'deck' to 'uucp' group (if needed)..."
if ! groups deck | grep -q '\buucp\b'; then
   sudo usermod -aG uucp deck
   echo "User 'deck' added to 'uucp' group. Logout/reboot needed for change to apply."
else
   echo "User 'deck' already in 'uucp' group."
fi

echo "[Step 8/8] Re-enabling read-only filesystem..."
sudo steamos-readonly enable

# Stop the keepalive background process
kill $SUDO_KEEPALIVE_PID

echo "--------------------------------------------"
echo "Setup script complete!"
echo "If the 'deck' user was just added to the 'uucp' group, you MUST log out"
echo "and log back into Desktop Mode or reboot for changes to take effect."
echo "You can test the setup by plugging in your Monome device."
echo "============================================"

exit 0
