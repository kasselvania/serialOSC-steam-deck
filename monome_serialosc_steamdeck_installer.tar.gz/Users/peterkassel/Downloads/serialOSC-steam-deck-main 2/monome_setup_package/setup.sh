#!/bin/bash
# Exit immediately if a command exits with a non-zero status.
set -e

echo "============================================"
echo "Monome SerialOSC & Virtual MIDI Setup for Steam Deck" # Updated Title
echo "============================================"
echo "This script will install serialoscd, libmonome,"
echo "the udev rule, enable the systemd service,"
echo "ensure required kernel modules are loaded/configured," # Updated Desc
echo "and initialize pacman keys if needed."
echo "It requires sudo access and will temporarily"
echo "disable the read-only filesystem."
echo "--------------------------------------------"

# Get sudo password upfront and keep the session alive
echo "Please enter your sudo password if prompted:"
sudo -v
while true; do sudo -n true; sleep 60; kill -0 "$$" || exit; done 2>/dev/null &
SUDO_KEEPALIVE_PID=$!
# Ensure the keepalive stops when the script exits
trap "kill $SUDO_KEEPALIVE_PID" EXIT

# Define source paths (relative to script location) and target paths
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
SERIALOSCD_SOURCE="$SCRIPT_DIR/usr/local/bin/serialoscd"
LIBMONOME_SOURCE_DIR="$SCRIPT_DIR/usr/local/lib"
UDEV_RULE_SOURCE="$SCRIPT_DIR/etc/udev/rules.d/99-monome.rules"
SYSTEMD_SERVICE_SOURCE="$SCRIPT_DIR/etc/systemd/system/serialoscd@.service"

SERIALOSCD_TARGET="/usr/local/bin/serialoscd"
LIBMONOME_TARGET_DIR="/usr/local/lib"
UDEV_RULE_TARGET="/etc/udev/rules.d/99-monome.rules"
SYSTEMD_SERVICE_TARGET="/etc/systemd/system/serialoscd@.service"

# --- Installation Steps ---

echo "[Step 1/13] Disabling read-only filesystem..."
sudo steamos-readonly disable

echo "[Step 2/13] Attempting to kill any lingering serialoscd processes..."
# Kill any running instances and ignore errors if none are found
sudo killall serialoscd || true
sleep 1 # Give a brief moment for processes to terminate

echo "[Step 3/13] Initializing and Populating Pacman Keyring (if needed)..."
# Initialize keyring if it doesn't exist (command exits cleanly if already initialized)
sudo pacman-key --init
# Populate with default Arch Linux, Holo, and SteamOS keys
# Ignore errors if specific keyrings don't exist, archlinux should be present
sudo pacman-key --populate archlinux holo steamos || echo "WARNING: Populating some keyrings failed, continuing with archlinux keys..."
echo "Pacman keyring checked/initialized."

echo "[Step 4/13] Installing required system dependencies (libuv, liblo)..."
# Now run the install command
# --noconfirm avoids asking user, --needed skips if already installed
sudo pacman -Syu --noconfirm --needed libuv liblo || echo "WARNING: Failed to automatically install dependencies. Please install libuv and liblo manually using pacman."

echo "[Step 5/13] Creating target directories (if needed)..."
sudo mkdir -p "$(dirname "$SERIALOSCD_TARGET")"
sudo mkdir -p "$LIBMONOME_TARGET_DIR"
sudo mkdir -p "$(dirname "$UDEV_RULE_TARGET")"
sudo mkdir -p "$(dirname "$SYSTEMD_SERVICE_TARGET")"
# <<< ADDED STEP >>> Ensure modules-load.d directory exists
sudo mkdir -p /etc/modules-load.d

echo "[Step 6/13] Copying files..."
sudo cp "$SERIALOSCD_SOURCE" "$SERIALOSCD_TARGET"
sudo cp "$LIBMONOME_SOURCE_DIR"/libmonome.so* "$LIBMONOME_TARGET_DIR/"
sudo cp "$UDEV_RULE_SOURCE" "$UDEV_RULE_TARGET"
sudo cp "$SYSTEMD_SERVICE_SOURCE" "$SYSTEMD_SERVICE_TARGET"
echo "Files copied."

echo "[Step 7/13] Setting permissions..."
sudo chmod 755 "$SERIALOSCD_TARGET"
sudo chmod 644 "$LIBMONOME_TARGET_DIR"/libmonome.so*
sudo chmod 644 "$UDEV_RULE_TARGET"
sudo chmod 644 "$SYSTEMD_SERVICE_TARGET"
echo "Permissions set."

echo "[Step 8/13] Reloading system daemons and udev rules..."
sudo systemctl daemon-reload
sudo udevadm control --reload-rules
echo "Daemons and rules reloaded."

echo "[Step 9/13] Ensuring FTDI and Virtual MIDI kernel modules are loaded..."
sudo modprobe ftdi_sio
sudo modprobe snd_virmidi # <<< ADDED modprobe command
echo "Attempted to load ftdi_sio and snd_virmidi modules."

# <<< ADDED STEP for Persistent Virtual MIDI >>>
echo "[Step 10/13] Configuring Virtual MIDI module to load on boot..."
# Create a configuration file to load snd_virmidi automatically
# Use printf with sudo tee to write the file as root, ensuring it has the correct content
printf "snd_virmidi\n" | sudo tee /etc/modules-load.d/virtual-midi.conf > /dev/null
echo "Configured snd_virmidi to load on boot via /etc/modules-load.d/virtual-midi.conf"

echo "[Step 11/13] Enabling serialoscd service for ttyUSB0..."
# Enable the service for ttyUSB0 specifically. Assumes device is usually ttyUSB0.
sudo systemctl enable serialoscd@ttyUSB0.service
echo "Enabled serialoscd@ttyUSB0.service."

echo "[Step 12/13] Adding user 'deck' to 'uucp' group (if needed)..."
if ! groups deck | grep -q '\buucp\b'; then
   sudo usermod -aG uucp deck
   echo "User 'deck' added to 'uucp' group. Logout/reboot needed for change to apply."
else
   echo "User 'deck' already in 'uucp' group."
fi

# Re-enabling read-only happens LAST now
echo "[Step 13/13] Re-enabling read-only filesystem..."
sudo steamos-readonly enable

# Stop the keepalive background process
kill $SUDO_KEEPALIVE_PID

echo "--------------------------------------------"
echo "Setup script complete!"
echo "SerialOSC service enabled for ttyUSB0."
echo "Virtual MIDI module (snd_virmidi) configured to load on boot."
echo "If the 'deck' user was just added to the 'uucp' group, you MUST log out"
echo "and log back into Desktop Mode or reboot for changes to take effect."
echo "You can test serialosc by plugging/re-plugging your Monome device."
echo "Virtual MIDI ports should be available after next reboot (check with 'aconnect -l')."
echo "============================================"

exit 0